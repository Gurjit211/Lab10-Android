package com.study.receiver

import android.os.Bundle
import android.os.Parcelable
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.study.receiver.ui.theme.CaseStudyReceiverTheme
import kotlinx.parcelize.Parcelize

@Parcelize
data class Contact (val name:String, val phone:String, val email:String): Parcelable

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val contact = intent.getParcelableExtra("contact", Contact::class.java)
        contact?.let {
            findViewById<TextView>(R.id.contactTextView).text = "Name: ${it.name}\nPhone: ${it.phone}\nEmail: ${it.email}"
        }
    }
}
